function Smile(){
    return(
        <div>
            <input/>
        </div>
    )
}
export default Smile