import Home from "./Components/Home";
import "./App.css";
import "./Fonts.css";
import "./Animations.css";
import MedCardReg from "./Components/MedCardReg";
import { Navigate, Route, Routes } from "react-router";
import Doctors from "./Components/Doctors";
import Meeting from "./Components/Meeting";
import DeliveryBoy from "./Components/DelivartBoy";
import TrackDelivery from "./Components/Track";
import Docmet from "./doctor meet";
import Glitch from "./Components/Glitch";
import Auth from "../pages/auth";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import ReportAnalysisPage from "../pages/ReportAnalysisPage";

const App = () => {
  localStorage.setItem("delivery", false);

  const isAuthenticated = !!localStorage.getItem("user");

  const ProtectedRoute = ({element}) => {
    if (!isAuthenticated) {
      toast.warning("Please log in to access this page!", { position: "top-right" });
      return <Navigate to="/" />;
    }
    return element;
  };

  return (
    <>
      <ToastContainer />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/doctors"  element={<Doctors />}  />
        <Route path="/medcardreg/:doctorId"  element={<MedCardReg />} />
        <Route path="/meeting/:userid"  element={<Meeting />} />
        <Route path="/delivary"  element={<DeliveryBoy />}  />
        <Route path="/track"  element={<TrackDelivery />}  />
        <Route path="/doc"  element={<Docmet />}  />
        <Route path="/error" element={<Glitch />} />
        <Route path="/reports" element={<ReportAnalysisPage/>}/>
        <Route path="/auth" element={<Auth />} />
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </>
  );
};

export default App;